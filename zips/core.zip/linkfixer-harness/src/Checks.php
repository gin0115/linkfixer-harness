<?php
/**
 * Server side checks the checklist panel asks about.
 *
 * @package LinkFixer_Harness
 */

namespace LinkFixer_Harness;

use Internet_Archive\Wayback_Machine_Link_Fixer\Link\Link;
use Internet_Archive\Wayback_Machine_Link_Fixer\Link\Link_Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Evaluates checks with a "type" of option, action, link_row or calls.
 */
class Checks {

	public const SERVER_TYPES = array( 'option', 'action', 'link_row', 'calls', 'post_meta', 'meta_count' );

	/**
	 * Whether a check is answered on the server.
	 *
	 * @param array<string, mixed> $check The check.
	 *
	 * @return boolean
	 */
	public static function is_server( array $check ): bool {
		return in_array( $check['type'] ?? '', self::SERVER_TYPES, true );
	}

	/**
	 * Runs one server side check.
	 *
	 * option   - name, and is (equals, null means not set) or has (a list or text contains it).
	 * action   - hook, status (one or a list), count or min, and optionally args, url (only that link's jobs),
	 *            within (seconds either side of now) or due_min / due_max (seconds from now).
	 * link_row - url, field (broken, excluded, archived, archived_href, process, checks, last_code, redirect, message),
	 *            and is (equals) or has (contains).
	 * calls    - method, url_has, min and optionally max.
	 * post_meta - post, key, and is (equals) or within (a timestamp within that many seconds of now); neither means set.
	 * meta_count - posts (ids), key, is: how many of the posts have the key.
	 *
	 * @param array<string, mixed> $check The check.
	 *
	 * @return array{say:string, pass:bool, detail:string}
	 */
	public static function run( array $check ): array {
		try {
			return self::evaluate( $check );
		} catch ( \Throwable $e ) {
			return array(
				'say'    => (string) ( $check['say'] ?? $check['type'] ),
				'pass'   => false,
				'detail' => get_class( $e ) . ': ' . $e->getMessage(),
			);
		}
	}

	/**
	 * Evaluates a check.
	 *
	 * @param array<string, mixed> $check The check.
	 *
	 * @return array{say:string, pass:bool, detail:string}
	 */
	private static function evaluate( array $check ): array {
		switch ( $check['type'] ) {
			case 'option':
				$actual = get_option( $check['name'], null );
				// "has": a list contains the value, or text contains it. "is": equals.
				if ( isset( $check['has'] ) ) {
					$pass = is_array( $actual )
						? in_array( (string) $check['has'], array_map( 'strval', $actual ), true )
						: false !== strpos( (string) $actual, (string) $check['has'] );
				} else {
					$pass = self::same( $actual, $check['is'] );
				}
				return array(
					'say'    => $check['say'] ?? 'Setting ' . $check['name'] . ( isset( $check['has'] ) ? ' contains ' . wp_json_encode( $check['has'] ) : ' is ' . wp_json_encode( $check['is'] ) ),
					'pass'   => $pass,
					'detail' => 'found ' . wp_json_encode( $actual ),
				);

			case 'action':
				$count = count( self::action_ids( $check ) );
				return array(
					'say'    => $check['say'] ?? sprintf( 'Background job "%1$s" (%2$s)', $check['hook'], implode( ' or ', (array) $check['status'] ) ),
					'pass'   => isset( $check['count'] ) ? (int) $check['count'] === $count : $count >= (int) ( $check['min'] ?? 1 ),
					'detail' => 'found ' . $count,
				);

			case 'link_row':
				$link   = ( new Link_Repository() )->find_by_url( (string) $check['url'] );
				$actual = null === $link ? null : self::link_field( $link, (string) $check['field'] );
				// "has" means the field contains that text, "is" means it equals the value.
				$pass = null !== $link && ( isset( $check['has'] )
					? false !== strpos( (string) $actual, (string) $check['has'] )
					: self::same( $actual, $check['is'] ) );
				return array(
					'say'    => $check['say'] ?? sprintf( 'Link %1$s: %2$s %3$s %4$s', $check['url'], $check['field'], isset( $check['has'] ) ? 'contains' : 'is', wp_json_encode( $check['has'] ?? $check['is'] ) ),
					'pass'   => $pass,
					'detail' => null === $link ? 'link row not found' : 'found ' . wp_json_encode( $actual ),
				);

			case 'calls':
				global $wpdb;
				$table = Call_Log::table();
				$count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE method = %s AND url LIKE %s", $check['method'], '%' . $wpdb->esc_like( (string) $check['url_has'] ) . '%' ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
				return array(
					'say'    => $check['say'] ?? sprintf( 'Archive.org was asked %1$s about %2$s', $check['method'], $check['url_has'] ),
					'pass'   => $count >= (int) ( $check['min'] ?? 1 ) && ( ! isset( $check['max'] ) || $count <= (int) $check['max'] ),
					'detail' => 'found ' . $count,
				);

			case 'post_meta':
				$actual = get_post_meta( (int) $check['post'], (string) $check['key'], true );
				if ( isset( $check['within'] ) ) {
					$pass = '' !== $actual && abs( time() - (int) $actual ) <= (int) $check['within'];
				} elseif ( array_key_exists( 'is', $check ) ) {
					$pass = self::same( $actual, $check['is'] );
				} else {
					$pass = '' !== $actual;
				}
				return array(
					'say'    => $check['say'] ?? sprintf( 'Post %1$d: %2$s', $check['post'], $check['key'] ),
					'pass'   => $pass,
					'detail' => 'found ' . wp_json_encode( $actual ),
				);

			case 'meta_count':
				$posts = array_map( 'intval', (array) $check['posts'] );
				$count = count( array_filter( $posts, static fn( $post_id ) => metadata_exists( 'post', $post_id, (string) $check['key'] ) ) );
				return array(
					'say'    => $check['say'] ?? sprintf( '%1$d posts have %2$s', $check['is'], $check['key'] ),
					'pass'   => (int) $check['is'] === $count,
					'detail' => sprintf( 'found %1$d of %2$d', $count, count( $posts ) ),
				);
		}

		return array(
			'say'    => 'Unknown check ' . $check['type'],
			'pass'   => false,
			'detail' => '',
		);
	}

	/**
	 * Action Scheduler action ids matching a check.
	 *
	 * The status may be a list: Action Scheduler's async runner can finish a job before anyone looks for it pending.
	 *
	 * @param array<string, mixed> $check hook, status, optional args and within.
	 *
	 * @return int[]
	 */
	private static function action_ids( array $check ): array {
		$ids = array();
		foreach ( (array) $check['status'] as $status ) {
			$query = array(
				'hook'     => $check['hook'],
				'status'   => $status,
				'per_page' => -1,
			);
			if ( isset( $check['args'] ) ) {
				$query['args'] = $check['args'];
			}
			$ids = array_merge( $ids, array_map( 'intval', (array) as_get_scheduled_actions( $query, 'ids' ) ) );
		}

		// Only jobs for one link.
		if ( isset( $check['url'] ) ) {
			$link    = ( new Link_Repository() )->find_by_url( (string) $check['url'] );
			$link_id = null === $link ? -1 : (int) $link->get_id();
			$ids     = array_values(
				array_filter(
					$ids,
					static fn( $id ) => (int) ( \ActionScheduler::store()->fetch_action( (string) $id )->get_args()['link_id'] ?? 0 ) === $link_id
				)
			);
		}

		// Due between due_min and due_max seconds from now.
		if ( isset( $check['due_min'] ) || isset( $check['due_max'] ) ) {
			$from = time() + (int) ( $check['due_min'] ?? PHP_INT_MIN );
			$to   = time() + (int) ( $check['due_max'] ?? 10 * YEAR_IN_SECONDS );
			$ids  = array_values(
				array_filter(
					$ids,
					static function ( $id ) use ( $from, $to ) {
						$time = \ActionScheduler::store()->get_date( $id )->getTimestamp();
						return $time >= $from && $time <= $to;
					}
				)
			);
		}

		// ActionScheduler_DBStore::get_date() is the due date for a pending job and the run date for any other.
		if ( isset( $check['within'] ) ) {
			$from = time() - (int) $check['within'];
			$to   = time() + (int) $check['within'];
			$ids  = array_values(
				array_filter(
					$ids,
					static function ( $id ) use ( $from, $to ) {
						$time = \ActionScheduler::store()->get_date( $id )->getTimestamp();
						return $time >= $from && $time <= $to;
					}
				)
			);
		}

		return $ids;
	}

	/**
	 * Reads one field of a link.
	 *
	 * @param Link   $link  The link.
	 * @param string $field The field.
	 *
	 * @return mixed
	 */
	private static function link_field( Link $link, string $field ) {
		switch ( $field ) {
			case 'broken':
				return $link->is_broken();
			case 'excluded':
				return $link->is_excluded();
			case 'archived':
				return '' !== (string) $link->get_archived_href();
			case 'archived_href':
				return (string) $link->get_archived_href();
			case 'process':
				return $link->get_archive_process();
			case 'checks':
				return count( $link->get_checks() );
			case 'last_code':
				$last = $link->get_last_check();
				return null === $last ? null : (int) $last['http_code'];
			case 'redirect':
				return (string) $link->get_redirect_href();
			case 'message':
				return $link->get_message();
		}
		return null;
	}

	/**
	 * Loose comparison: booleans by truthiness, lists in any order, everything else as strings.
	 *
	 * @param mixed $actual   Found value.
	 * @param mixed $expected Expected value.
	 *
	 * @return boolean
	 */
	private static function same( $actual, $expected ): bool {
		if ( null === $expected ) {
			return null === $actual;
		}
		if ( is_bool( $expected ) ) {
			return (bool) $actual === $expected;
		}
		if ( is_array( $expected ) ) {
			if ( ! is_array( $actual ) ) {
				return false;
			}
			$a = array_map( 'strval', array_values( $actual ) );
			$b = array_map( 'strval', array_values( $expected ) );
			sort( $a );
			sort( $b );
			return $a === $b;
		}
		return (string) $actual === (string) $expected;
	}
}
